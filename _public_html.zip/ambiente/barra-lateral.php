<?php
    session_start();
    include_once('conexao.php');

    // Verifica se o usuário está logado
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php'); // Redireciona para a página de login se não estiver logado
        exit;
    }

    $user_id = $_SESSION['user_id'];

    // Consulta os dados apenas do usuário logado
    $sql = "SELECT * FROM carrinho WHERE usuario_id = ? ORDER BY id DESC";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();


?>





<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu lateral</title>
     <style>
        body{
            font-family: Arial, Helvetica, sans-serif;
            margin: 0px;
            background-color:#0b0a0f;

        }
        a{
            text-decoration: none;
        }
        header{
            background-color: rgb(21, 4, 98  );
            padding: 10px;
        }
        .btn-abrir{
            color: white;
            font-size: 20px;
        }
        nav{
            height: 0%;
            width: 250px;
            background-color: rgb(21, 4, 98  ) ;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1;
            overflow: hidden;
            transition: width 0.3s;
        }
        nav a{
            color: white;
            font-size: 25px;
            display: block;
            padding: 12px 10px 12px 32px;
        }
        nav a:hover{
            color: rgb(21, 4, 98  );
            background-color: white;
        }
        main{
            padding: 10px;
            transition: margin-left 0.5s;
        }
        table,th,td{
            border: 1px solid black;
            border-collapse:collapse ;
        }
        th,td{
            padding: 5px 10px;
        }
        th{
            background-color: rgb(21, 4, 98);
            color: white;
        }
        /*odd aplicado em todos elementos inpares*/
        table tr:nth-child(odd){
            background-color: #ddd;

        }
        /*odd aplicado em todos elementos pares*/
        table tr:nth-child(even){
            background-color:white ;

        }
        div{
            display: inline-block;
            background-color: #060642 ;
            padding: 5px;
            text-align: center;
            width: 98.3%;
        }
        legend{
            color: white;
        }
        h3{
            color: blue;
        }
        p{
            color: white;
        }
        label{
            color:white;
        }
        #clientesTabela {
            width: 100%;
            border-collapse: collapse;
            left:50px;
        }
        @media screen and (max-width: 400px) {
            body {
                font-size: 8px;
            }

            .table {
                font-size: 5px;
                padding: 10px;
            }

            #clientesTabela th, #clientesTabela td {
                padding: 4px;
                font-size: 5px;
            }

            button {
                padding: 5px 10px;
                font-size: 12px;
            }

            #carrinho {
                width: 96%;
                padding: 5px;
            }

            #listaCarrinho li {
                padding: 3px 0;
            }
        }

    </style>
</head>
<body>
    
         <header>
            <!--criei uma class para usar no css e não ter conflito com outros links-->
            <a href="#" class="btn-abrir" onclick="abrirMenu()">&#9776; Menu</a>
    
        </header>
       
        <nav id="menu">
            <a href="#" onclick="facharMenu()">&times; Fechar</a>
            <a href="https://pdvvendas.shop/carrinho.php">Voltar</a>
            <!--<a href="sair.php">Sair</a>
            <a href="#">Contato</a>
            <a href="#">Mais opções</a>-->
        </nav>
   
        <main id="conteudo">
            
            
        
                <iframe title="relatorio_cpburguer" width="1500" height="800" src="https://app.powerbi.com/view?r=eyJrIjoiZDQ1Y2ExM2QtMjczNS00NjZhLWI1MDktZDE4MTQ0N2FjZTI1IiwidCI6Ijc5YTk0YThmLTA0NWYtNGNkNC04MTRhLTgwNTA5MzlhYTJjNCJ9" frameborder="0" allowFullScreen="true"></iframe>
            
    
        </main>
        
        <script>
        function abrirMenu() {
            document.getElementById('menu').style. height = '100%';
            document.getElementById('conteudo').style.marginLeft = '16%';
        }
        function facharMenu(){
            document.getElementById('menu').style. height = '0%'
            document.getElementById('conteudo').style.marginLeft = '0%';
        }

        
        
    </script>
    
</body>







</html>